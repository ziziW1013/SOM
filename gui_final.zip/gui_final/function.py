__author__ = 'wdy'

from PyQt5.QtWidgets import QApplication, QWidget, QFileDialog,QMessageBox,QGraphicsScene, QListWidgetItem,QListWidget
from PyQt5.QtCore import QFile,QTextStream,Qt
from PyQt5.Qt import QListWidget
from PyQt5.QtGui import QPixmap
from som_f1 import SOM
from SOMC import Ui_Dialog
from numpy import *
import numpy as np
import matplotlib.pyplot as plt

class Som(QWidget):
    def __init__(self, parent = None):
        super(Som, self).__init__(parent)
        # set up the user interface from designer
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        # pushbutton "Open File" connect to function open
        self.ui.pushButton.clicked.connect(self.open)

        # pushbutton_2(U-matrix) connect x,y,weight,T,sig,Learning_rate
        self.ui.pushButton_2.clicked.connect(self.show_matrix)
        # transfer button invisible
        self.ui.pushButton_2.setVisible(False)
        # pushbutton_3(transfer) can change the string to binary
        self.ui.pushButton_3.clicked.connect(self.transfer)
        # U-matrix button invisible
        self.ui.pushButton_3.setVisible(False)
        # pushbutton_3(train) connect the data that can click
        self.ui.pushButton_4.clicked.connect(self.show_choosedata)
        # Train button invisible
        self.ui.pushButton_4.setVisible(False)


    def open(self):
        self.fileName, _= QFileDialog.getOpenFileName(self)
        # transfer the csv file into txt type
        file = genfromtxt(self.fileName, delimiter=',', skiprows=1,dtype=str)

        for lineInArray in file:
            # read line by line from the file
            row = ""
            for item in lineInArray:
                row += item

            # add the lines into the GUI
            packagelist = QListWidgetItem()
            qtItem = QListWidgetItem(packagelist)
            qtItem.setText(row)
            #qtItem.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            self.ui.listWidget.addItem(qtItem)
            self.QTItem = qtItem
            #this for choose the different material function
        self.ui.listWidget.itemClicked.connect(self.item_clicked)
        #transfer button visible
        self.ui.pushButton_3.setVisible(True)

    # change string to binary
    def transfer(self):
        data = genfromtxt(self.fileName, delimiter=',', skiprows=1,dtype=str)
        #get the size of data set
        (x, y) = data.shape
        # b is the line of the data set
        b=0
        #statistic the number of different data
        d=0
        #initialize map for store how many lines in data set
        map1 = []
        array = []
        while b<y:
            # a is the row of data set
            a=0
            # store data in map, if the same data in different line consider different
            map = []
            while a < x:
                # if the data  occur before then add 0
                if data[a][b] in map:
                    # the row of data
                    a += 1
                else:
                    # put this data in map,initialize it for each layer
                    map.append(data[a][b])
                    # put this data in map1
                    map1.append(data[a][b])
                    d += 1
                    a += 1
            b += 1
            array.append(d)
        # build the map with size x and d
        by_map = zeros([x,d],dtype=int)

        # this is the way to set the correspond string variable as 1
        f=0
        a=array[0]
        # the different line
        while f<x:
            # in the first line if data is occur before
            # then set one
            if data[f][0] in map1:
                c=map1.index(data[f][0])
                by_map[f][c]=1
                f+=1

        i=0
        while i<y-1:
            a=array[i]
            b=array[i+1]
            f=0
            # in other line if data occur before
            while f<x:
                if data[f][i+1] in map1[a:b]:
                    c=map1[a:b].index(data[f][i+1])+a
                    by_map[f][c]=1
                    f+=1
            i+=1
        # save data in by_map
        by_map=np.savetxt('data.csv',by_map,delimiter=',',fmt="%s")
        #u-matrix is visible
        self.ui.pushButton_2.setVisible(True)
        #data = genfromtxt('data.csv', delimiter=',', skiprows=1,dtype=str)
        data = genfromtxt('data.csv', delimiter=',',dtype=str)
        return data


    def item_clicked(self):
        #get the item position in original file
        row = self.ui.listWidget.currentRow()
        return row

    #connect the function with each panel, get each value from panel
    def TrainContact(self):
        X = self.ui.X.value()
        Y = self.ui.Y.value()
        T = self.ui.T.value()
        Sig = self.ui.lineEdit.text()
        Learning_rate = self.ui.lineEdit_2.text()
        return X,Y,T,Sig,Learning_rate

    # warning message
    def warning(self):
        X,Y,T,Sig,Learning_rate = self.TrainContact()
        # if the neighborhood size is empty, then pop up the warning message
        if not Sig :
            QMessageBox.warning(self, "Empty", "please enter sig ")
            #throw an exception
            raise Exception ("no input Sig")
            return
        # if learning rate is empty, then pop up warning message
        if not Learning_rate:
            QMessageBox.warning(self, "Empty", "please enter Learning rate")
            #throw an exception
            raise Exception ("no input Learning rate")
            return
        #if X,Y,T is empty, then pop up warning message
        if X == 0 or Y == 0 or T == 0:
            #throw an exception
            QMessageBox.warning(self, "Empty", "please choose value")
            raise Exception ("no input X or Y or T")
            return

        return X,Y,T,Sig,Learning_rate


        #cannot change the data after enter once
        #self.ui.X.setReadOnly(True)
        #self.ui.Y.setReadOnly(True)
        #self.ui.WEIGHT.setReadOnly(True)
        #self.ui.T.setReadOnly(True)
        #self.ui.lineEdit.setReadOnly(True)
        #self.ui.lineEdit_2.setReadOnly(True)
        #self.ui.pushButton_2.setEnabled(True)

    # train the data used to U-MATRIX
    def usom(self):
        X,Y,T,Sig,Learning_rate = self.warning()
        Sig = float(Sig)
        Learning_rate = float(Learning_rate)
        data =self.transfer()
        WEIGHT = data.shape[1]
        self.som = SOM(X,Y,WEIGHT,Sig,Learning_rate,T)
        self.x = X
        self.y = Y
        return self.som


    def show_choosedata(self):
        data =self.transfer()
        i = self.item_clicked()
        # connect to click the material
        Choose = self.som
        Choose_data = Choose.Choose_data(data,i)
        #close the u-matrix
        plt.close()
        #show the train pattern
        plt.pcolor(Choose_data)
        plt.axis([0,self.x,0,self.y])
        plt.colorbar()
        # save the pattern in figure
        fig = plt.gcf()
        fig.set_size_inches(4,3)
        plt.savefig('test.png', format='png')
        plt.close(fig)
        #show figure in application
        scene = QGraphicsScene()
        pic = QPixmap('test.png')
        scene.addPixmap(pic)
        self.ui.graphicsView.setScene(scene)
        self.ui.graphicsView.show()

    def show_matrix(self):
        #self.warning()
        data =genfromtxt('data.csv',delimiter=',')
        data = apply_along_axis(lambda x:x/linalg.norm(x),1,data)
        #self.TrainContact()
        self.usom()
        train =self.som
        #connect to the train function in som_f1
        train.train(data)
        # show the u-matrix
        plt.imshow(train.U_matrix())
        plt.colorbar()
        # save as a figure
        fig = plt.gcf()
        fig.set_size_inches(3,2)
        plt.savefig('test1.png', format='png')
        plt.close(fig)
        # show in the right window
        scene1 = QGraphicsScene()
        pic1 = QPixmap('test1.png')
        scene1.addPixmap(pic1)
        self.ui.graphicsView_2.setScene(scene1)
        self.ui.graphicsView_2.show()
        self.ui.pushButton_4.setVisible(True)


if  __name__== '__main__':
    import sys
    app = QApplication(sys.argv)
    Som = Som()
    Som.show()
    sys.exit(app.exec_())
