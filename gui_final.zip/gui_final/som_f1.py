from numpy import *
import matplotlib.pyplot as plt


class SOM:
    def __init__(self,x,y,inputLen,sig,learn_rate,T):
        # initialized weight with small random values
        self.weight = random.rand(x,y,inputLen)
        #innitialize a map to store ||x-w||
        self.map = zeros((x,y))
        #normalization weight
        self.weight = array([w/linalg.norm(w) for w in self.weight])
        #size of the neighbourhood
        self.sig = sig
        #learning rate
        self.learn_rate = learn_rate
        #define the size of the SOM
        self.x = arange(x)
        self.y = arange(y)
        #Initializes the parameter T
        self.T = T
        #innitialize a map for topographic error
        self.map2 = zeros((x,y))
        #show the som of one data
        self.map3 = zeros((x,y))



    def getwinner(self,x):
        #get the index of the winner point
        #squared Euclidean distance between the input vector x and the weight w for each neuron
        dis = x-self.weight #x-w
        it = nditer(self.map,flags=['multi_index'])
        while not it.finished:
            self.map[it.multi_index]=linalg.norm(dis[it.multi_index]) #sum of x-w
            it.iternext()
        position = unravel_index(self.map.argmin(), self.map.shape)#from map find the position of the minimom
        return position


    def gaussian_func(self,c,sig):
        #T=exp(-s^2/2sig^2)
        #caculate topological neighbourhood
        xx,yy = meshgrid(self.x,self.y)
        pos = exp(-((xx-c[0])**2 + (yy-c[1])**2)/2*sig**2)
        return pos


    def cooperative(self,x,win,t):
        # the update of the learning rate
        up_rate = self.learn_rate*exp(-t/float(self.T))
        #the update of sig
        sig = self.sig*exp(-t/float(self.T))
        #S is the lateral distance between neurons i and j on the grid of neurons
        #win_pst is winner position
        h = self.gaussian_func(win,sig)*up_rate
        it = nditer(h, flags=['multi_index'])
        while not it.finished:
            self.weight[it.multi_index] += h[it.multi_index]*(x-self.weight[it.multi_index])
            #self.weight[it.multi_index] = self.weight[it.multi_index] / linalg.norm(self.weight[it.multi_index])
            it.iternext()

    #train the data
    def train(self,data):
        for i in data:
            # for t in T
            for iteration in range(self.T):
                # train the data
                self.cooperative(i,self.getwinner(i),iteration)


    def Choose_data(self,data,i):
        # the distance map
        map1=[]
        for n in data[i]:
            n = int(n)
            map1.append(n)
        map1 = asarray(map1)
        dis = map1-self.weight
        it = nditer(self.map3,flags=['multi_index'])
        while not it.finished:
            self.map3[it.multi_index]=linalg.norm(dis[it.multi_index])
            it.iternext()
        return self.map3



    def U_matrix(self):
        um = zeros((self.weight.shape[0]*2-1,self.weight.shape[1]*2-1))
        it = nditer(um, flags=['multi_index'])
        while not it.finished:
            # the odd line
            if it.multi_index[0]%2 == 0:
                    # the new data set is larger than original data set
                    if it.multi_index[1]<self.weight.shape[1]*2:
                        # the neuron in even column
                        # the neuron around on neuron
                        if it.multi_index[1]%2 == 0:
                            i=0
                            for ii in range(it.multi_index[0]/2-1,it.multi_index[0]/2+2):
                                for jj in range(it.multi_index[1]/2-1,it.multi_index[1]/2+2):
                                    if ii >= 0 and ii < self.weight.shape[0] and jj >= 0 and jj < self.weight.shape[1]:
                                        um[it.multi_index] += linalg.norm(self.weight[ii,jj,:]-self.weight[it.multi_index[0]/2][it.multi_index[1]/2])
                                        i+=1
                            um[it.multi_index]= um[it.multi_index]/i
                            it.iternext()
                        # the neuron in odd column
                        else:
                            # the neuron next to it
                            um[it.multi_index] = linalg.norm(self.weight[it.multi_index[0]/2][(it.multi_index[1]+1)/2]-self.weight[it.multi_index[0]/2][(it.multi_index[1]-1)/2])
                            it.iternext()

            # the double line
            else:
                    if it.multi_index[1]<self.weight.shape[1]*2:
                        if  it.multi_index[1]%2 == 0:
                            #the neuron below to it
                            um[it.multi_index] = linalg.norm(self.weight[(it.multi_index[0]+1)/2][it.multi_index[1]/2]-self.weight[(it.multi_index[0]-1)/2][it.multi_index[1]/2])
                            it.iternext()
                        else:
                            # the neuron across to each other
                            um[it.multi_index] =linalg.norm( 0.5*((self.weight[(it.multi_index[0]+1)/2][(it.multi_index[1]+1)/2] -self.weight[(it.multi_index[0]-1)/2][(it.multi_index[1]-1)/2])
                                                                  +(self.weight[(it.multi_index[0]+1)/2][it.multi_index[1]/2] -self.weight[it.multi_index[0]/2][(it.multi_index[1]-1)/2])))

                            it.iternext()


        return um


    #def X_Y(self):
     #   return self.x, self.y